"""Tornado eventloop integration for pyzmq"""

from tornado.ioloop import IOLoop

__all__ = ['IOLoop']
